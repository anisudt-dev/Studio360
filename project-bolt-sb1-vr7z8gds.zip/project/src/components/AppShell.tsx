import { useState, type ReactNode } from 'react';
import {
  LayoutDashboard, Users, CalendarCheck, Wallet,
  CalendarDays, FileText, BarChart3, Settings, Home, Menu as MenuIcon,
  Plus, Search, Camera, ChevronDown, User, Package,
} from 'lucide-react';
import { useNav } from '@/lib/nav';
import { NAV_ITEMS, MOBILE_NAV, MORE_NAV } from '@/lib/constants';

const ICONS: Record<string, any> = {
  LayoutDashboard, Users, CalendarCheck, Wallet,
  CalendarDays, FileText, BarChart3, Settings, Home, Menu: MenuIcon, Package,
};

export function AppShell({ children }: { children: ReactNode }) {
  const { route, navigate, setSearchOpen, openModal } = useNav();
  const [moreOpen, setMoreOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);

  const isActive = (page: string) => route.page === page || route.page === `${page}-detail`;

  function handleNav(page: string) {
    navigate({ page });
    setMoreOpen(false);
  }

  return (
    <div className="min-h-screen flex bg-[#f7f8fa]">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 border-r border-gray-200 bg-white shrink-0 sticky top-0 h-screen">
        <div className="px-5 py-5 flex items-center gap-2.5 border-b border-gray-100">
          <div className="w-9 h-9 rounded-xl bg-teal-700 flex items-center justify-center text-white shrink-0">
            <Camera size={18} />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold text-gray-900">Studio Manager</p>
            <p className="text-[11px] text-gray-400">Photography Business</p>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = ICONS[item.icon] || LayoutDashboard;
            const active = isActive(item.id);
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  active
                    ? 'bg-teal-50 text-teal-700'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
              >
                <Icon size={18} className={active ? 'text-teal-600' : 'text-gray-400'} />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="px-3 py-4 border-t border-gray-100">
          <div className="rounded-xl bg-gray-50 px-3 py-2.5 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center text-teal-700 text-xs font-bold shrink-0">S</div>
            <div className="leading-tight min-w-0">
              <p className="text-xs font-semibold text-gray-900 truncate">Studio Admin</p>
              <p className="text-[11px] text-gray-400">Local workspace</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-200">
          <div className="flex items-center gap-3 px-4 lg:px-6 h-16">
            {/* Mobile logo */}
            <div className="lg:hidden flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-700 flex items-center justify-center text-white">
                <Camera size={16} />
              </div>
            </div>

            {/* Search trigger */}
            <button
              onClick={() => setSearchOpen(true)}
              className="flex-1 max-w-md flex items-center gap-2.5 rounded-xl border border-gray-200 bg-gray-50 px-3.5 py-2 text-sm text-gray-400 hover:border-gray-300 hover:bg-white transition-colors"
            >
              <Search size={16} />
              <span className="hidden sm:inline">Search customers, bookings...</span>
              <span className="sm:hidden">Search...</span>
              <kbd className="hidden md:inline ml-auto text-[10px] font-semibold text-gray-400 bg-white border border-gray-200 rounded px-1.5 py-0.5">⌘K</kbd>
            </button>

            <div className="flex-1 lg:hidden" />

            {/* Quick add */}
            <div className="relative">
              <button
                onClick={() => setQuickAddOpen((v) => !v)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-teal-700 text-white px-3 py-2 text-sm font-semibold hover:bg-teal-800 transition-colors shadow-sm"
              >
                <Plus size={16} />
                <span className="hidden sm:inline">Add</span>
                <ChevronDown size={14} className="hidden sm:inline" />
              </button>
              {quickAddOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setQuickAddOpen(false)} />
                  <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-gray-200 py-1.5 z-50 animate-scale-in">
                    {[
                      { label: 'New Booking', icon: CalendarCheck, action: () => openModal('addBooking', {}) },
                      { label: 'New Customer', icon: User, action: () => openModal('addCustomer', {}) },
                      { label: 'Record Payment', icon: Wallet, action: () => openModal('recordPayment', {}) },
                    ].map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.label}
                          onClick={() => { item.action(); setQuickAddOpen(false); }}
                          className="w-full flex items-center gap-2.5 px-3.5 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                          <Icon size={16} className="text-gray-400" />
                          {item.label}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-5 lg:p-8 pb-24 lg:pb-8 max-w-[1400px] w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-gray-200 flex items-center justify-around px-2 h-16 safe-area">
        {MOBILE_NAV.map((item) => {
          const Icon = ICONS[item.icon] || Home;
          const active = isActive(item.id);
          if (item.id === 'more') {
            return (
              <button
                key={item.id}
                onClick={() => setMoreOpen(true)}
                className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg ${active ? 'text-teal-600' : 'text-gray-500'}`}
              >
                <Icon size={20} />
                <span className="text-[10px] font-medium">{item.label}</span>
              </button>
            );
          }
          return (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg ${active ? 'text-teal-600' : 'text-gray-500'}`}
            >
              <Icon size={20} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Mobile "more" sheet */}
      {moreOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex items-end" onClick={() => setMoreOpen(false)}>
          <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm animate-fade-in" />
          <div className="relative w-full bg-white rounded-t-2xl p-4 animate-slide-up" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-4" />
            <div className="grid grid-cols-3 gap-3">
              {MORE_NAV.map((item) => {
                const Icon = ICONS[item.icon] || LayoutDashboard;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNav(item.id)}
                    className="flex flex-col items-center gap-2 rounded-xl border border-gray-100 py-4 hover:bg-gray-50"
                  >
                    <Icon size={22} className="text-teal-600" />
                    <span className="text-xs font-medium text-gray-700">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
