import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, PageHeader, Input, Button, Skeleton } from '@/components/ui';
import { toast } from '@/components/Toast';
import type { Settings as SettingsType } from '@/lib/types';

export function SettingsPage() {
  const [settings, setSettings] = useState<SettingsType | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ studio_name: '', currency_symbol: '₹', phone: '', email: '', address: '' });

  useEffect(() => {
    supabase.from('settings').select('*').limit(1).maybeSingle().then(({ data }) => {
      const s = data as SettingsType | null;
      setSettings(s);
      if (s) setForm({
        studio_name: s.studio_name || '',
        currency_symbol: s.currency_symbol || '₹',
        phone: s.phone || '',
        email: s.email || '',
        address: s.address || '',
      });
      setLoading(false);
    });
  }, []);

  async function handleSave() {
    setSaving(true);
    if (settings) {
      const { error } = await supabase.from('settings').update(form).eq('id', settings.id);
      setSaving(false);
      if (error) { toast('Could not save settings', 'error'); return; }
    } else {
      const { error } = await supabase.from('settings').insert(form);
      setSaving(false);
      if (error) { toast('Could not save settings', 'error'); return; }
    }
    toast('Settings saved', 'success');
  }

  if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-32" /><Skeleton className="h-64" /></div>;

  return (
    <div>
      <PageHeader title="Settings" subtitle="Configure your studio details" />

      <div className="max-w-2xl space-y-6">
        <Card className="p-6">
          <h3 className="text-sm font-bold text-gray-900 mb-4">Studio Information</h3>
          <div className="space-y-4">
            <Input label="Studio Name" value={form.studio_name} onChange={(e) => setForm({ ...form, studio_name: e.target.value })} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Currency Symbol" value={form.currency_symbol} onChange={(e) => setForm({ ...form, currency_symbol: e.target.value })} />
              <Input label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <Input label="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
          <div className="mt-6 flex justify-end">
            <Button onClick={handleSave} loading={saving}>Save Settings</Button>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-sm font-bold text-gray-900 mb-2">About</h3>
          <p className="text-sm text-gray-500">Studio ERP is a lightweight photography studio management system. Your data is stored securely and connected across customers, bookings, payments, and invoices.</p>
        </Card>
      </div>
    </div>
  );
}
