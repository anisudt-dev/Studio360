import { useMemo, useState } from 'react';
import { Users, Plus, Search, Phone, ChevronRight } from 'lucide-react';
import { useCustomers, useBookings } from '@/lib/hooks';
import { useNav } from '@/lib/nav';
import { Card, Button, PageHeader, EmptyState, Skeleton, Badge } from '@/components/ui';
import { formatCurrency, formatDate, daysFromNow } from '@/lib/format';
import { paymentStatus, PAYMENT_STATUS_STYLE } from '@/lib/constants';

const CURRENCY = '₹';

export function CustomersPage() {
  const { customers, loading } = useCustomers();
  const { bookings } = useBookings();
  const { navigate, openModal } = useNav();
  const [search, setSearch] = useState('');

  const enriched = useMemo(() => {
    return customers.map((c) => {
      const cBookings = bookings.filter((b) => b.customer_id === c.id && b.status !== 'cancelled');
      const outstanding = cBookings.reduce((s, b) => s + Math.max(0, b.balance), 0);
      const lastEvent = cBookings
        .filter((b) => b.event_date)
        .sort((a, b) => (a.event_date! < b.event_date! ? 1 : -1))[0];
      return { ...c, eventCount: cBookings.length, outstanding, lastEvent };
    });
  }, [customers, bookings]);

  const filtered = useMemo(() => {
    if (!search) return enriched;
    const q = search.toLowerCase();
    return enriched.filter((c) =>
      c.name.toLowerCase().includes(q) || (c.mobile || '').includes(search) || (c.email || '').toLowerCase().includes(q)
    );
  }, [enriched, search]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Customers"
        subtitle={`${customers.length} ${customers.length === 1 ? 'customer' : 'customers'} in your studio`}
        actions={
          <Button onClick={() => openModal('addCustomer', {})}><Plus size={16} /> Add Customer</Button>
        }
      />

      <div className="relative mb-4 max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          className="w-full rounded-xl border border-gray-200 bg-white pl-10 pr-3.5 py-2.5 text-sm focus-ring focus:border-teal-500"
          placeholder="Search by name, mobile, or email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Users size={26} />}
            title={search ? 'No customers found' : 'No customers yet'}
            description={search ? 'Try a different search term' : 'Add your first customer to start creating bookings'}
            action={!search && <Button onClick={() => openModal('addCustomer', {})}><Plus size={16} /> Add Customer</Button>}
          />
        </Card>
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-gray-400 border-b border-gray-100">
                  <th className="font-medium py-3 px-4">Customer</th>
                  <th className="font-medium py-3 px-4">Mobile</th>
                  <th className="font-medium py-3 px-4 text-center">Events</th>
                  <th className="font-medium py-3 px-4">Last Event</th>
                  <th className="font-medium py-3 px-4 text-right">Outstanding</th>
                  <th className="font-medium py-3 px-4 w-8"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((c) => {
                  const ps = c.outstanding > 0 ? paymentStatus(c.outstanding, c.lastEvent?.event_date || null) : 'paid';
                  const pstyle = PAYMENT_STATUS_STYLE[ps];
                  return (
                    <tr key={c.id} onClick={() => navigate({ page: 'customer', id: c.id })} className="hover:bg-gray-50/50 cursor-pointer transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center text-xs font-bold shrink-0">
                            {c.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                          </div>
                          <span className="font-semibold text-gray-900">{c.name}</span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-gray-600">{c.mobile || '—'}</td>
                      <td className="py-3 px-4 text-center text-gray-600">{c.eventCount}</td>
                      <td className="py-3 px-4 text-gray-500">{c.lastEvent ? `${formatDate(c.lastEvent.event_date)}` : '—'}</td>
                      <td className="py-3 px-4 text-right">
                        {c.outstanding > 0 ? (
                          <span className="font-semibold text-red-600">{formatCurrency(c.outstanding, CURRENCY)}</span>
                        ) : (
                          <Badge className={pstyle.badge} dot={pstyle.dot}>Paid</Badge>
                        )}
                      </td>
                      <td className="py-3 px-4 text-gray-300"><ChevronRight size={16} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-2">
            {filtered.map((c) => (
              <Card key={c.id} onClick={() => navigate({ page: 'customer', id: c.id })} hover className="p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center text-sm font-bold shrink-0">
                    {c.name.split(' ').map((n) => n[0]).slice(0, 2).join('')}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 truncate">{c.name}</p>
                    <p className="text-xs text-gray-500 flex items-center gap-1">
                      {c.mobile ? <><Phone size={11} /> {c.mobile}</> : 'No mobile'}
                    </p>
                  </div>
                  <div className="text-right">
                    {c.outstanding > 0 ? (
                      <p className="text-sm font-semibold text-red-600">{formatCurrency(c.outstanding, CURRENCY)}</p>
                    ) : (
                      <Badge className="bg-emerald-50 text-emerald-700" dot="bg-emerald-500">Paid</Badge>
                    )}
                    <p className="text-[11px] text-gray-400 mt-0.5">{c.eventCount} events</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
