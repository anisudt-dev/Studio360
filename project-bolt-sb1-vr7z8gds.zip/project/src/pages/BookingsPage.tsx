import { useMemo, useState } from 'react';
import { Plus, Search, CalendarCheck, ChevronRight, MapPin, Wallet } from 'lucide-react';
import { useBookings } from '@/lib/hooks';
import { useNav } from '@/lib/nav';
import { Card, Button, PageHeader, EmptyState, Skeleton, Badge, Select } from '@/components/ui';
import { formatCurrency, formatDate, daysFromNow } from '@/lib/format';
import {
  BOOKING_STATUS_STYLE, PROJECT_STATUS_STYLE, nextAction, EVENT_TYPES,
} from '@/lib/constants';
import type { BookingWithCustomer } from '@/lib/types';

const CURRENCY = '₹';

export function BookingsPage() {
  const { bookings, loading } = useBookings();
  const { navigate, openModal } = useNav();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  const filtered = useMemo(() => {
    return bookings
      .filter((b) => {
        if (statusFilter !== 'all' && b.project_status !== statusFilter) return false;
        if (typeFilter !== 'all' && b.event_type !== typeFilter) return false;
        if (search) {
          const q = search.toLowerCase();
          return (
            (b.customer?.name || '').toLowerCase().includes(q) ||
            (b.title || '').toLowerCase().includes(q) ||
            b.event_type.toLowerCase().includes(q) ||
            (b.venue || '').toLowerCase().includes(q) ||
            (b.customer?.mobile || '').includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        const ad = a.event_date || '9999';
        const bd = b.event_date || '9999';
        return ad < bd ? -1 : 1;
      });
  }, [bookings, search, statusFilter, typeFilter]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-40" />
        <div className="grid gap-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Bookings"
        subtitle={`${bookings.length} total`}
        actions={<Button onClick={() => openModal('addBooking', {})}><Plus size={16} /> New Booking</Button>}
      />

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1 max-w-md">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            className="w-full rounded-xl border border-gray-200 bg-white pl-10 pr-3.5 py-2.5 text-sm focus-ring focus:border-teal-500"
            placeholder="Search by name, mobile, venue..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="py-2">
            <option value="all">All Types</option>
            {EVENT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </Select>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="py-2">
            <option value="all">All Status</option>
            <option value="confirmed">Confirmed</option>
            <option value="shooting">Shooting</option>
            <option value="editing">Editing</option>
            <option value="delivered">Delivered</option>
          </Select>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<CalendarCheck size={26} />}
            title={search || statusFilter !== 'all' || typeFilter !== 'all' ? 'No bookings match your filters' : 'No bookings yet'}
            description={search || statusFilter !== 'all' || typeFilter !== 'all' ? 'Try clearing filters' : 'Create your first booking to get started'}
            action={!search && statusFilter === 'all' && typeFilter === 'all' && <Button onClick={() => openModal('addBooking', {})}><Plus size={16} /> New Booking</Button>}
          />
        </Card>
      ) : (
        <>
          {/* Desktop table — familiar Excel-like layout */}
          <Card className="hidden md:block overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-gray-400 border-b border-gray-100">
                  <th className="font-medium py-3 px-4">Customer</th>
                  <th className="font-medium py-3 px-4">Event</th>
                  <th className="font-medium py-3 px-4">Date</th>
                  <th className="font-medium py-3 px-4 text-right">Total</th>
                  <th className="font-medium py-3 px-4 text-right">Paid</th>
                  <th className="font-medium py-3 px-4 text-right">Balance</th>
                  <th className="font-medium py-3 px-4">Status</th>
                  <th className="font-medium py-3 px-4">Next</th>
                  <th className="font-medium py-3 px-4 w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((b) => {
                  const ps = PROJECT_STATUS_STYLE[b.project_status];
                  const action = nextAction(b);
                  const dn = daysFromNow(b.event_date);
                  const dayLabel = dn === 0 ? 'Today' : dn === 1 ? 'Tomorrow' : dn === -1 ? 'Yesterday' : formatDate(b.event_date);
                  return (
                    <tr key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} className="hover:bg-gray-50/50 cursor-pointer transition-colors">
                      <td className="py-3 px-4">
                        <p className="font-semibold text-gray-900">{b.title || b.customer?.name || '—'}</p>
                        {b.venue && <p className="text-xs text-gray-400 mt-0.5 truncate max-w-[140px]">{b.venue}</p>}
                      </td>
                      <td className="py-3 px-4 text-gray-600">{b.event_type}</td>
                      <td className="py-3 px-4 text-gray-600 whitespace-nowrap">{dayLabel}</td>
                      <td className="py-3 px-4 text-right font-semibold text-gray-900 whitespace-nowrap">{formatCurrency(b.total_amount, CURRENCY)}</td>
                      <td className="py-3 px-4 text-right text-emerald-600 whitespace-nowrap">{b.paid_amount > 0 ? formatCurrency(b.paid_amount, CURRENCY) : '—'}</td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {b.balance > 0 ? <span className="font-semibold text-red-600">{formatCurrency(b.balance, CURRENCY)}</span> : <span className="text-gray-400">—</span>}
                      </td>
                      <td className="py-3 px-4"><Badge className={ps.badge} dot={ps.dot}>{ps.label}</Badge></td>
                      <td className="py-3 px-4">
                        <span className={`text-xs ${action.type === 'payment' ? 'text-amber-600 font-medium' : 'text-gray-400'}`}>{action.label}</span>
                      </td>
                      <td className="py-3 px-4 text-gray-300"><ChevronRight size={16} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile / tablet cards */}
          <div className="md:hidden space-y-2">
            {filtered.map((b) => {
              const bs = BOOKING_STATUS_STYLE[b.status];
              const ps = PROJECT_STATUS_STYLE[b.project_status];
              const action = nextAction(b);
              const dn = daysFromNow(b.event_date);
              const dayLabel = dn === 0 ? 'Today' : dn === 1 ? 'Tomorrow' : dn === -1 ? 'Yesterday' : formatDate(b.event_date);
              return (
                <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <p className="text-base font-semibold text-gray-900 truncate">{b.title || b.customer?.name}</p>
                      <p className="text-sm text-gray-500 mt-0.5">{b.event_type} · {dayLabel}</p>
                      {b.venue && <p className="text-sm text-gray-400 mt-0.5 flex items-center gap-1"><MapPin size={12} /> {b.venue}</p>}
                    </div>
                    <div className="flex flex-col items-end gap-1.5 shrink-0">
                      <p className="text-lg font-bold text-gray-900">{formatCurrency(b.total_amount, CURRENCY)}</p>
                      <div className="flex gap-1.5">
                        {b.paid_amount > 0 && <span className="text-xs text-emerald-600">Paid {formatCurrency(b.paid_amount, CURRENCY)}</span>}
                        {b.balance > 0 && <span className="text-xs text-red-600 font-semibold">Bal {formatCurrency(b.balance, CURRENCY)}</span>}
                      </div>
                      <Badge className={ps.badge} dot={ps.dot}>{ps.label}</Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-50">
                    <span className={`text-xs font-medium ${action.type === 'payment' ? 'text-amber-600' : 'text-gray-400'}`}>
                      NEXT: {action.label}
                    </span>
                    {action.type === 'payment' && (
                      <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openModal('recordPayment', { bookingId: b.id }); }}>
                        <Wallet size={13} /> Pay
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
