import { useMemo, useState } from 'react';
import {
  Camera, Wallet, Scissors, Package, ArrowRight, MapPin,
} from 'lucide-react';
import { useBookings } from '@/lib/hooks';
import { useNav } from '@/lib/nav';
import { Card, Badge, Skeleton, Button } from '@/components/ui';
import {
  formatCurrency, formatDate, formatTime, greeting, daysFromNow, todayISO,
} from '@/lib/format';
import {
  PROJECT_STATUS_STYLE, paymentStatus, nextAction,
} from '@/lib/constants';
import type { BookingWithCustomer } from '@/lib/types';

const CURRENCY = '₹';

export function DashboardPage() {
  const { bookings, loading } = useBookings();
  const { navigate, openModal } = useNav();
  const [view, setView] = useState<'today' | 'upcoming'>('today');

  const today = todayISO();

  const todaysShoots = useMemo(() =>
    bookings.filter((b) => b.event_date === today && b.status !== 'cancelled' && b.project_status === 'confirmed')
      .sort((a, b) => (a.start_time || '99') < (b.start_time || '99') ? -1 : 1),
    [bookings, today]);

  const pendingPayments = useMemo(() =>
    bookings.filter((b) => {
      if (b.status === 'cancelled' || b.balance <= 0) return false;
      const ps = paymentStatus(b.balance, b.event_date);
      return ps === 'overdue' || ps === 'due' || b.event_date === today;
    }),
    [bookings, today]);

  const editingJobs = useMemo(() =>
    bookings.filter((b) => b.status !== 'cancelled' && b.project_status === 'editing'),
    [bookings]);

  const deliveryDue = useMemo(() =>
    bookings.filter((b) => b.status !== 'cancelled' && b.project_status === 'editing')
      .filter((b) => {
        if (!b.event_date) return false;
        return daysFromNow(b.event_date) <= 3;
      }),
    [bookings]);

  const pendingTotal = useMemo(() =>
    bookings.reduce((s, b) => s + (b.balance > 0 && b.status !== 'cancelled' ? b.balance : 0), 0),
    [bookings]);

  const upcomingWeek = useMemo(() =>
    bookings
      .filter((b) => b.event_date && b.status !== 'cancelled' && daysFromNow(b.event_date) >= 0 && daysFromNow(b.event_date) <= 7)
      .sort((a, b) => (a.event_date! < b.event_date! ? -1 : 1))
      .slice(0, 8),
    [bookings]);

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  const dateStr = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'short' });

  return (
    <div className="space-y-6">
      {/* Greeting + date */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">{greeting()}</h1>
        <p className="text-base text-gray-500 mt-1">{dateStr}</p>
      </div>

      {/* Summary numbers — minimal, no decoration */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryStat count={todaysShoots.length} label="Shoots Today" onClick={() => navigate({ page: 'calendar' })} />
        <SummaryStat count={pendingPayments.length} label="Payments Due" sub={formatCurrency(pendingTotal, CURRENCY)} onClick={() => navigate({ page: 'payments' })} />
        <SummaryStat count={editingJobs.length} label="In Editing" onClick={() => navigate({ page: 'deliverables' })} />
        <SummaryStat count={deliveryDue.length} label="Delivery Due" onClick={() => navigate({ page: 'deliverables' })} />
      </div>

      {/* Today / Upcoming toggle */}
      <div className="flex items-center gap-1 bg-gray-100 rounded-xl p-1 w-fit">
        <button
          onClick={() => setView('today')}
          className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${view === 'today' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
        >
          Today
        </button>
        <button
          onClick={() => setView('upcoming')}
          className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${view === 'upcoming' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
        >
          Upcoming
        </button>
      </div>

      {/* TODAY view */}
      {view === 'today' && (
        <div className="space-y-6">
          {/* Today's shoots */}
          <Section title="Today's Shoots" empty="No shoots scheduled today">
            {todaysShoots.length === 0 ? null : (
              <div className="space-y-2">
                {todaysShoots.map((b) => {
                  const ps = PROJECT_STATUS_STYLE[b.project_status];
                  const action = nextAction(b);
                  return (
                    <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="text-center shrink-0 w-14">
                          <p className="text-base font-bold text-gray-900">{formatTime(b.start_time) || '—'}</p>
                        </div>
                        <div className="w-px self-stretch bg-gray-100" />
                        <div className="flex-1 min-w-0">
                          <p className="text-base font-semibold text-gray-900 truncate">{b.title || b.customer?.name}</p>
                          <p className="text-sm text-gray-500 mt-0.5">{b.event_type}</p>
                          {b.venue && <p className="text-sm text-gray-400 mt-0.5 flex items-center gap-1"><MapPin size={12} /> {b.venue}</p>}
                          {b.balance > 0 && <p className="text-sm text-red-600 mt-1 font-medium">{formatCurrency(b.balance, CURRENCY)} balance</p>}
                        </div>
                        <div className="flex flex-col items-end gap-1.5 shrink-0">
                          <Badge className={ps.badge} dot={ps.dot}>{ps.label}</Badge>
                          <span className={`text-xs font-medium ${action.type === 'payment' ? 'text-amber-600' : 'text-gray-400'}`}>
                            NEXT: {action.label}
                          </span>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </Section>

          {/* Payments due today */}
          <Section title="Payments Due" empty="No payments due right now">
            {pendingPayments.length === 0 ? null : (
              <div className="space-y-2">
                {pendingPayments.slice(0, 5).map((b) => {
                  const ps = paymentStatus(b.balance, b.event_date);
                  const severity = ps === 'overdue' ? 'text-red-600' : 'text-amber-600';
                  return (
                    <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4 flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-base font-semibold text-gray-900 truncate">{b.title || b.customer?.name}</p>
                        <p className="text-sm text-gray-500 mt-0.5">{b.event_type} · {formatDate(b.event_date)}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <p className={`text-lg font-bold ${severity}`}>{formatCurrency(b.balance, CURRENCY)}</p>
                        <p className={`text-xs ${severity}`}>{ps === 'overdue' ? 'Overdue' : 'Due'}</p>
                      </div>
                      <Button size="sm" onClick={(e) => { e.stopPropagation(); openModal('recordPayment', { bookingId: b.id }); }}>
                        <Wallet size={13} /> Collect
                      </Button>
                    </Card>
                  );
                })}
              </div>
            )}
          </Section>

          {/* In editing */}
          <Section title="In Editing" empty="No jobs in editing right now">
            {editingJobs.length === 0 ? null : (
              <div className="space-y-2">
                {editingJobs.slice(0, 5).map((b) => {
                  const action = nextAction(b);
                  return (
                    <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4 flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <p className="text-base font-semibold text-gray-900 truncate">{b.title || b.customer?.name}</p>
                        <p className="text-sm text-gray-500 mt-0.5">{b.event_type} · Shot {formatDate(b.event_date)}</p>
                      </div>
                      <span className="text-xs font-medium text-gray-400 shrink-0">NEXT: {action.label}</span>
                    </Card>
                  );
                })}
              </div>
            )}
          </Section>
        </div>
      )}

      {/* UPCOMING view */}
      {view === 'upcoming' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-900">This Week</h2>
            <button onClick={() => navigate({ page: 'bookings' })} className="text-sm font-semibold text-teal-600 hover:text-teal-700 flex items-center gap-1">
              All bookings <ArrowRight size={14} />
            </button>
          </div>
          {upcomingWeek.length === 0 ? (
            <Card className="p-12 text-center">
              <p className="text-gray-400 mb-3">No events this week</p>
              <Button onClick={() => openModal('addBooking', {})}>New Booking</Button>
            </Card>
          ) : (
            <div className="space-y-2">
              {upcomingWeek.map((b) => {
                const ps = PROJECT_STATUS_STYLE[b.project_status];
                const dn = daysFromNow(b.event_date);
                const dayLabel = dn === 0 ? 'Today' : dn === 1 ? 'Tomorrow' : formatDate(b.event_date);
                const action = nextAction(b);
                return (
                  <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0 flex-1">
                        <p className="text-base font-semibold text-gray-900 truncate">{b.title || b.customer?.name}</p>
                        <p className="text-sm text-gray-500 mt-0.5">
                          {dayLabel} · {b.event_type}
                          {b.venue && <span className="text-gray-400"> · {b.venue}</span>}
                        </p>
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-sm font-semibold text-gray-900">{formatCurrency(b.total_amount, CURRENCY)}</span>
                          {b.paid_amount > 0 && <span className="text-sm text-emerald-600">Paid {formatCurrency(b.paid_amount, CURRENCY)}</span>}
                          {b.balance > 0 && <span className="text-sm text-red-600">Balance {formatCurrency(b.balance, CURRENCY)}</span>}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1.5 shrink-0">
                        <Badge className={ps.badge} dot={ps.dot}>{ps.label}</Badge>
                        <span className={`text-xs font-medium ${action.type === 'payment' ? 'text-amber-600' : 'text-gray-400'}`}>
                          NEXT: {action.label}
                        </span>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SummaryStat({ count, label, sub, onClick }: {
  count: number; label: string; sub?: string; onClick?: () => void;
}) {
  return (
    <Card onClick={onClick} hover={!!onClick} className="p-5">
      <p className="text-3xl font-bold text-gray-900 leading-none">{count}</p>
      <p className="text-sm text-gray-500 mt-2">{label}</p>
      {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
    </Card>
  );
}

function Section({ title, empty, children }: { title: string; empty: string; children?: React.ReactNode }) {
  const hasContent = children !== null && children !== undefined;
  return (
    <div>
      <h2 className="text-base font-bold text-gray-900 mb-3">{title}</h2>
      {hasContent ? children : (
        <Card className="p-6 text-center">
          <p className="text-sm text-gray-400">{empty}</p>
        </Card>
      )}
    </div>
  );
}
