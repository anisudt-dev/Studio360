import { useMemo, useState } from 'react';
import { Plus, Wallet, Search, TrendingUp, AlertCircle } from 'lucide-react';
import { usePayments, useBookings } from '@/lib/hooks';
import { useNav } from '@/lib/nav';
import { Card, Button, PageHeader, EmptyState, Skeleton, Badge } from '@/components/ui';
import { formatCurrency, formatDate, daysFromNow, todayISO } from '@/lib/format';
import { paymentStatus, PAYMENT_STATUS_STYLE } from '@/lib/constants';

const CURRENCY = '₹';

export function PaymentsPage() {
  const { payments, loading: payLoading } = usePayments();
  const { bookings, loading: bookLoading } = useBookings();
  const { navigate, openModal } = useNav();
  const [search, setSearch] = useState('');

  const summary = useMemo(() => {
    const totalReceivable = bookings.reduce((s, b) => s + (b.status !== 'cancelled' ? Math.max(0, b.balance) : 0), 0);
    const dueThisWeek = bookings.reduce((s, b) => {
      if (b.status === 'cancelled' || b.balance <= 0 || !b.event_date) return s;
      const dn = daysFromNow(b.event_date);
      return dn >= 0 && dn <= 7 ? s + b.balance : s;
    }, 0);
    const overdue = bookings.reduce((s, b) => {
      if (b.status === 'cancelled' || b.balance <= 0 || !b.event_date) return s;
      return daysFromNow(b.event_date) < 0 ? s + b.balance : s;
    }, 0);
    return { totalReceivable, dueThisWeek, overdue };
  }, [bookings]);

  const paymentBookings = useMemo(() => {
    return bookings
      .filter((b) => b.status !== 'cancelled')
      .map((b) => {
        const ps = paymentStatus(b.balance, b.event_date);
        return { ...b, payStatus: ps };
      })
      .sort((a, b) => {
        const order = { overdue: 0, due: 1, partial: 2, paid: 3 };
        return order[a.payStatus as keyof typeof order] - order[b.payStatus as keyof typeof order];
      });
  }, [bookings]);

  const filtered = useMemo(() => {
    if (!search) return paymentBookings;
    const q = search.toLowerCase();
    return paymentBookings.filter((b) =>
      (b.customer?.name || '').toLowerCase().includes(q) ||
      b.event_type.toLowerCase().includes(q)
    );
  }, [paymentBookings, search]);

  const loading = payLoading || bookLoading;

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-10 w-40" /><div className="grid grid-cols-3 gap-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}</div><Skeleton className="h-64" /></div>;
  }

  return (
    <div>
      <PageHeader
        title="Payments"
        subtitle="Track receivables and record payments"
        actions={<Button onClick={() => openModal('recordPayment', {})}><Plus size={16} /> Record Payment</Button>}
      />

      {/* Summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gray-100 text-gray-600 flex items-center justify-center"><Wallet size={18} /></div>
            <p className="text-sm font-medium text-gray-500">Total Receivable</p>
          </div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(summary.totalReceivable, CURRENCY)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center"><TrendingUp size={18} /></div>
            <p className="text-sm font-medium text-gray-500">Due This Week</p>
          </div>
          <p className="text-2xl font-bold text-amber-600">{formatCurrency(summary.dueThisWeek, CURRENCY)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center"><AlertCircle size={18} /></div>
            <p className="text-sm font-medium text-gray-500">Overdue</p>
          </div>
          <p className="text-2xl font-bold text-red-600">{formatCurrency(summary.overdue, CURRENCY)}</p>
        </Card>
      </div>

      {/* Search */}
      <div className="relative mb-4 max-w-md">
        <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          className="w-full rounded-xl border border-gray-200 bg-white pl-10 pr-3.5 py-2.5 text-sm focus-ring focus:border-teal-500"
          placeholder="Search by customer or event..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {filtered.length === 0 ? (
        <Card><EmptyState icon={<Wallet size={26} />} title={search ? 'No results' : 'No bookings'} description={search ? 'Try a different search' : 'Bookings will appear here once created'} /></Card>
      ) : (
        <>
          {/* Desktop table */}
          <Card className="hidden md:block overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-gray-400 border-b border-gray-100">
                  <th className="font-medium py-3 px-4">Customer</th>
                  <th className="font-medium py-3 px-4">Event</th>
                  <th className="font-medium py-3 px-4 text-right">Total</th>
                  <th className="font-medium py-3 px-4 text-right">Paid</th>
                  <th className="font-medium py-3 px-4 text-right">Balance</th>
                  <th className="font-medium py-3 px-4">Due Date</th>
                  <th className="font-medium py-3 px-4">Status</th>
                  <th className="font-medium py-3 px-4 w-8"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {filtered.map((b) => {
                  const style = PAYMENT_STATUS_STYLE[b.payStatus];
                  return (
                    <tr key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} className="hover:bg-gray-50/50 cursor-pointer">
                      <td className="py-3 px-4 font-semibold text-gray-900">{b.customer?.name}</td>
                      <td className="py-3 px-4 text-gray-600">{b.event_type}</td>
                      <td className="py-3 px-4 text-right font-semibold text-gray-900 whitespace-nowrap">{formatCurrency(b.total_amount, CURRENCY)}</td>
                      <td className="py-3 px-4 text-right text-emerald-600 whitespace-nowrap">{formatCurrency(b.paid_amount, CURRENCY)}</td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">{b.balance > 0 ? <span className="font-semibold text-red-600">{formatCurrency(b.balance, CURRENCY)}</span> : <span className="text-gray-400">—</span>}</td>
                      <td className="py-3 px-4 text-gray-500 whitespace-nowrap">{formatDate(b.event_date)}</td>
                      <td className="py-3 px-4"><Badge className={style.badge} dot={style.dot}>{style.label}</Badge></td>
                      <td className="py-3 px-4">
                        {b.balance > 0 && (
                          <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openModal('recordPayment', { bookingId: b.id }); }}>Pay</Button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards */}
          <div className="md:hidden space-y-2">
            {filtered.map((b) => {
              const style = PAYMENT_STATUS_STYLE[b.payStatus];
              return (
                <Card key={b.id} onClick={() => navigate({ page: 'booking', id: b.id })} hover className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-semibold text-gray-900">{b.customer?.name}</p>
                    <Badge className={style.badge} dot={style.dot}>{style.label}</Badge>
                  </div>
                  <p className="text-xs text-gray-500 mb-2">{b.event_type} · {formatDate(b.event_date)}</p>
                  <div className="flex items-center justify-between text-sm pt-2 border-t border-gray-50">
                    <div className="flex gap-3 text-xs">
                      <span className="text-gray-400">Total <span className="font-semibold text-gray-700">{formatCurrency(b.total_amount, CURRENCY)}</span></span>
                      {b.balance > 0 && <span className="text-red-500">Due <span className="font-semibold">{formatCurrency(b.balance, CURRENCY)}</span></span>}
                    </div>
                    {b.balance > 0 && <Button size="sm" variant="ghost" onClick={(e) => { e.stopPropagation(); openModal('recordPayment', { bookingId: b.id }); }}>Pay</Button>}
                  </div>
                </Card>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
