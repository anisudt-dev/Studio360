import { useMemo } from 'react';
import { TrendingUp, CalendarCheck, Wallet, CheckCircle2, XCircle, BarChart3 } from 'lucide-react';
import { useBookings } from '@/lib/hooks';
import { Card, PageHeader, Skeleton, ProgressBar } from '@/components/ui';
import { formatCurrency, formatDate, daysFromNow } from '@/lib/format';
import { EVENT_TYPES, PROJECT_STATUS_STYLE } from '@/lib/constants';

const CURRENCY = '₹';

export function ReportsPage() {
  const { bookings, loading } = useBookings();

  const stats = useMemo(() => {
    const active = bookings.filter((b) => b.status !== 'cancelled');
    const totalValue = active.reduce((s, b) => s + b.total_amount, 0);
    const collected = active.reduce((s, b) => s + b.paid_amount, 0);
    const pending = active.reduce((s, b) => s + Math.max(0, b.balance), 0);
    const completed = active.filter((b) => b.project_status === 'delivered').length;
    const cancelled = bookings.filter((b) => b.status === 'cancelled').length;
    return { count: active.length, totalValue, collected, pending, completed, cancelled };
  }, [bookings]);

  const monthly = useMemo(() => {
    const now = new Date();
    const months: { label: string; value: number; collected: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const label = d.toLocaleDateString('en-IN', { month: 'short' });
      const monthBookings = bookings.filter((b) => {
        if (!b.event_date || b.status === 'cancelled') return false;
        const bd = new Date(b.event_date);
        return bd.getMonth() === d.getMonth() && bd.getFullYear() === d.getFullYear();
      });
      months.push({
        label,
        value: monthBookings.reduce((s, b) => s + b.total_amount, 0),
        collected: monthBookings.reduce((s, b) => s + b.paid_amount, 0),
      });
    }
    return months;
  }, [bookings]);

  const maxMonth = Math.max(...monthly.map((m) => m.value), 1);

  const byType = useMemo(() => {
    const map: Record<string, { count: number; value: number }> = {};
    bookings.filter((b) => b.status !== 'cancelled').forEach((b) => {
      if (!map[b.event_type]) map[b.event_type] = { count: 0, value: 0 };
      map[b.event_type].count++;
      map[b.event_type].value += b.total_amount;
    });
    return Object.entries(map).sort((a, b) => b[1].value - a[1].value);
  }, [bookings]);

  if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-32" /><div className="grid grid-cols-2 lg:grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28" />)}</div><Skeleton className="h-64" /></div>;

  return (
    <div>
      <PageHeader title="Reports" subtitle="Business overview at a glance" />

      {/* Business overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><CalendarCheck size={16} className="text-teal-600" /><p className="text-xs font-medium text-gray-500">Bookings</p></div>
          <p className="text-2xl font-bold text-gray-900">{stats.count}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><TrendingUp size={16} className="text-blue-600" /><p className="text-xs font-medium text-gray-500">Booking Value</p></div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.totalValue, CURRENCY)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><Wallet size={16} className="text-emerald-600" /><p className="text-xs font-medium text-gray-500">Collected</p></div>
          <p className="text-2xl font-bold text-emerald-600">{formatCurrency(stats.collected, CURRENCY)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><Wallet size={16} className="text-red-600" /><p className="text-xs font-medium text-gray-500">Pending</p></div>
          <p className="text-2xl font-bold text-red-600">{formatCurrency(stats.pending, CURRENCY)}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Monthly revenue chart */}
        <Card className="p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-4 flex items-center gap-2"><BarChart3 size={16} className="text-gray-400" /> Monthly Revenue</h3>
          <div className="flex items-end justify-between gap-2 h-40">
            {monthly.map((m) => (
              <div key={m.label} className="flex-1 flex flex-col items-center gap-2">
                <div className="w-full flex flex-col justify-end items-center gap-1" style={{ height: '120px' }}>
                  <div className="w-full max-w-[40px] bg-teal-600 rounded-t-lg transition-all" style={{ height: `${(m.value / maxMonth) * 100}%` }} title={formatCurrency(m.value, CURRENCY)} />
                </div>
                <span className="text-[11px] text-gray-400">{m.label}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-gray-50 text-xs text-gray-400">
            <span>Last 6 months</span>
            <span className="font-semibold text-gray-600">{formatCurrency(monthly.reduce((s, m) => s + m.value, 0), CURRENCY)} total</span>
          </div>
        </Card>

        {/* Events by type */}
        <Card className="p-5">
          <h3 className="text-sm font-bold text-gray-900 mb-4">Events by Type</h3>
          {byType.length === 0 ? (
            <p className="text-sm text-gray-400 py-8 text-center">No data</p>
          ) : (
            <div className="space-y-3">
              {byType.slice(0, 6).map(([type, data]) => {
                const maxVal = byType[0][1].value;
                return (
                  <div key={type}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-gray-700">{type}</span>
                      <span className="text-xs text-gray-400">{data.count} · {formatCurrency(data.value, CURRENCY)}</span>
                    </div>
                    <ProgressBar value={(data.value / maxVal) * 100} />
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      {/* Completion stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><CheckCircle2 size={16} className="text-emerald-600" /><p className="text-xs font-medium text-gray-500">Completed</p></div>
          <p className="text-2xl font-bold text-gray-900">{stats.completed}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><XCircle size={16} className="text-red-600" /><p className="text-xs font-medium text-gray-500">Cancelled</p></div>
          <p className="text-2xl font-bold text-gray-900">{stats.cancelled}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><TrendingUp size={16} className="text-amber-600" /><p className="text-xs font-medium text-gray-500">Avg. Booking</p></div>
          <p className="text-2xl font-bold text-gray-900">{formatCurrency(stats.count > 0 ? stats.totalValue / stats.count : 0, CURRENCY)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-2"><Wallet size={16} className="text-teal-600" /><p className="text-xs font-medium text-gray-500">Collection Rate</p></div>
          <p className="text-2xl font-bold text-gray-900">{stats.totalValue > 0 ? Math.round((stats.collected / stats.totalValue) * 100) : 0}%</p>
        </Card>
      </div>
    </div>
  );
}
