import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, MapPin, Clock, CalendarDays } from 'lucide-react';
import { useBookings } from '@/lib/hooks';
import { useNav } from '@/lib/nav';
import { Card, Button, PageHeader, Skeleton, Badge } from '@/components/ui';
import { formatDate, formatTime, monthLabel, todayISO, daysFromNow } from '@/lib/format';
import { PROJECT_STATUS_STYLE } from '@/lib/constants';
import type { BookingWithCustomer } from '@/lib/types';

export function CalendarPage() {
  const { bookings, loading } = useBookings();
  const { navigate } = useNav();
  const [view, setView] = useState<'today' | 'week' | 'month'>('month');
  const [current, setCurrent] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(todayISO());

  const today = todayISO();

  const eventsByDate = useMemo(() => {
    const map: Record<string, BookingWithCustomer[]> = {};
    bookings.forEach((b) => {
      if (b.event_date && b.status !== 'cancelled') {
        if (!map[b.event_date]) map[b.event_date] = [];
        map[b.event_date].push(b);
      }
    });
    return map;
  }, [bookings]);

  const calendarDays = useMemo(() => {
    const year = current.getFullYear();
    const month = current.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startWeekday = firstDay.getDay();
    const days: (Date | null)[] = [];
    for (let i = 0; i < startWeekday; i++) days.push(null);
    for (let d = 1; d <= lastDay.getDate(); d++) days.push(new Date(year, month, d));
    return days;
  }, [current]);

  const weekDays = useMemo(() => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const startWeekday = start.getDay();
    start.setDate(start.getDate() - startWeekday);
    const days: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      days.push(d);
    }
    return days;
  }, []);

  const todayEvents = useMemo(() => (eventsByDate[today] || []).sort((a, b) => (a.start_time || '99') < (b.start_time || '99') ? -1 : 1), [eventsByDate, today]);

  const weekEvents = useMemo(() => {
    const list: BookingWithCustomer[] = [];
    weekDays.forEach((d) => {
      const iso = d.toISOString().slice(0, 10);
      (eventsByDate[iso] || []).forEach((b) => list.push(b));
    });
    return list;
  }, [eventsByDate, weekDays]);

  const selectedEvents = selectedDate ? (eventsByDate[selectedDate] || []) : [];

  function prevMonth() { setCurrent(new Date(current.getFullYear(), current.getMonth() - 1, 1)); }
  function nextMonth() { setCurrent(new Date(current.getFullYear(), current.getMonth() + 1, 1)); }

  if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-40" /><Skeleton className="h-96" /></div>;

  return (
    <div>
      <PageHeader
        title="Calendar"
        actions={
          <div className="flex items-center gap-1 bg-gray-100 rounded-xl p-1">
            {(['today', 'week', 'month'] as const).map((v) => (
              <button
                key={v}
                onClick={() => setView(v)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors capitalize ${view === v ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500'}`}
              >
                {v}
              </button>
            ))}
          </div>
        }
      />

      {/* TODAY view */}
      {view === 'today' && (
        <div className="space-y-3">
          <p className="text-sm text-gray-500">{formatDate(today)}</p>
          {todayEvents.length === 0 ? (
            <Card className="p-12 text-center">
              <CalendarDays className="mx-auto text-gray-300 mb-3" size={32} />
              <p className="text-gray-400">No events today</p>
            </Card>
          ) : (
            todayEvents.map((b) => <EventCard key={b.id} booking={b} onClick={() => navigate({ page: 'booking', id: b.id })} />)
          )}
        </div>
      )}

      {/* WEEK view */}
      {view === 'week' && (
        <div className="space-y-4">
          {weekDays.map((d) => {
            const iso = d.toISOString().slice(0, 10);
            const events = eventsByDate[iso] || [];
            const isToday = iso === today;
            const dn = daysFromNow(iso);
            const dayLabel = dn === 0 ? 'Today' : dn === 1 ? 'Tomorrow' : d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
            return (
              <div key={iso}>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-sm font-semibold ${isToday ? 'text-teal-700' : 'text-gray-700'}`}>{dayLabel}</span>
                  {events.length > 0 && <span className="text-xs text-gray-400">{events.length} event{events.length !== 1 ? 's' : ''}</span>}
                </div>
                {events.length > 0 && (
                  <div className="space-y-2">
                    {events.map((b) => <EventCard key={b.id} booking={b} onClick={() => navigate({ page: 'booking', id: b.id })} />)}
                  </div>
                )}
              </div>
            );
          })}
          {weekEvents.length === 0 && (
            <Card className="p-12 text-center">
              <CalendarDays className="mx-auto text-gray-300 mb-3" size={32} />
              <p className="text-gray-400">No events this week</p>
            </Card>
          )}
        </div>
      )}

      {/* MONTH view */}
      {view === 'month' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-gray-900">{monthLabel(current)}</h2>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" onClick={prevMonth}><ChevronLeft size={18} /></Button>
                <Button variant="ghost" size="icon" onClick={() => { setCurrent(new Date()); setSelectedDate(today); setView('today'); }}>Today</Button>
                <Button variant="ghost" size="icon" onClick={nextMonth}><ChevronRight size={18} /></Button>
              </div>
            </div>
            <div className="grid grid-cols-7 gap-1 mb-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                <div key={d} className="text-center text-xs font-semibold text-gray-400 py-2">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {calendarDays.map((date, i) => {
                if (!date) return <div key={i} />;
                const iso = date.toISOString().slice(0, 10);
                const events = eventsByDate[iso] || [];
                const isToday = iso === today;
                const isSelected = iso === selectedDate;
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedDate(iso)}
                    className={`aspect-square rounded-lg p-1.5 text-left transition-colors border ${
                      isSelected ? 'border-teal-600 bg-teal-50' : 'border-transparent hover:border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <span className={`text-xs font-semibold block ${isToday ? 'text-teal-700' : 'text-gray-700'}`}>
                      {date.getDate()}
                      {isToday && <span className="inline-block w-1 h-1 rounded-full bg-teal-600 ml-1 align-middle" />}
                    </span>
                    {events.length > 0 && (
                      <div className="mt-1 space-y-0.5">
                        {events.slice(0, 2).map((b) => {
                          const ps = PROJECT_STATUS_STYLE[b.project_status];
                          return (
                            <div key={b.id} className={`text-[10px] truncate rounded px-1 py-0.5 ${ps.badge}`}>
                              {b.event_type}
                            </div>
                          );
                        })}
                        {events.length > 2 && <div className="text-[10px] text-gray-400">+{events.length - 2} more</div>}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Day detail */}
          <Card className="p-5">
            <h3 className="text-sm font-bold text-gray-900 mb-1">
              {selectedDate ? formatDate(selectedDate) : 'Select a date'}
            </h3>
            <p className="text-xs text-gray-400 mb-4">{selectedEvents.length} event{selectedEvents.length !== 1 ? 's' : ''}</p>
            {selectedEvents.length === 0 ? (
              <div className="py-10 text-center">
                <CalendarDays className="mx-auto text-gray-300 mb-2" size={28} />
                <p className="text-sm text-gray-400">No events on this day</p>
              </div>
            ) : (
              <div className="space-y-2">
                {selectedEvents.map((b) => <EventCard key={b.id} booking={b} onClick={() => navigate({ page: 'booking', id: b.id })} compact />)}
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}

function EventCard({ booking: b, onClick, compact }: { booking: BookingWithCustomer; onClick: () => void; compact?: boolean }) {
  const ps = PROJECT_STATUS_STYLE[b.project_status];
  return (
    <button onClick={onClick} className="w-full text-left p-3 rounded-xl border border-gray-100 hover:bg-gray-50/50 transition-colors">
      <div className="flex items-center justify-between mb-1">
        <p className="text-sm font-semibold text-gray-900">{b.title || b.customer?.name}</p>
        <Badge className={ps.badge} dot={ps.dot}>{ps.label}</Badge>
      </div>
      <p className="text-xs text-gray-500">{b.event_type}</p>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 mt-1.5">
        {b.start_time && <span className="text-xs text-gray-400 flex items-center gap-1"><Clock size={11} /> {formatTime(b.start_time)}</span>}
        {b.venue && <span className="text-xs text-gray-400 flex items-center gap-1"><MapPin size={11} /> {b.venue}</span>}
      </div>
    </button>
  );
}
